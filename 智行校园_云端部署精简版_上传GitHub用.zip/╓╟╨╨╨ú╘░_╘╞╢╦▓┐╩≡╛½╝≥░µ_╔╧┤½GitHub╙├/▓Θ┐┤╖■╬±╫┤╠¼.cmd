@echo off
chcp 65001 >nul
cd /d "%~dp0"
if not exist "%~dp0runtime\node.exe" (
  echo 缺少随附运行环境，请完整解压整个项目。
  pause
  exit /b 1
)
"%~dp0runtime\node.exe" "%~dp0server\control.js" status
if errorlevel 1 (
  echo 操作未完成，请查看上方错误和server\storage\logs\service.log。
  pause
  exit /b 1
)
pause
