@echo off
chcp 65001 >nul
cd /d "%~dp0"
if not exist "%~dp0runtime\node.exe" (
 echo 请完整解压项目后运行，缺少runtime\node.exe。
 pause
 exit /b 1
)
"%~dp0runtime\node.exe" "%~dp0server\persistent.js" enable
if errorlevel 1 (
 echo 启动未完成，请查看上方错误。不要同时启动其他目录的服务。
 pause
 exit /b 1
)
echo 服务已在后台运行，已启用本用户登录Windows后自动启动和异常恢复。
echo 手机与电脑需连接同一网络；首次使用请重新编译预览，再点击自动检测并连接。
pause
