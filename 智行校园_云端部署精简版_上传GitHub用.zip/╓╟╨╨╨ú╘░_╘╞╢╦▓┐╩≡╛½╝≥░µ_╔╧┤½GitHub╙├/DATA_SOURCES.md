# 数据来源与许可

本工程没有使用爬取的商业地图截图或虚构的校园建筑。

## 1 OpenStreetMap 校园几何

- 来源：© OpenStreetMap contributors。
- 数据许可：Open Database License 1.0 (ODbL)。
- 版权与署名说明：https://www.openstreetmap.org/copyright
- 许可全文：https://opendatacommons.org/licenses/odbl/1-0/
- 快照取得日期：2026-10-16。
- 西校区边界：https://www.openstreetmap.org/way/360350324
- 东校区边界：https://www.openstreetmap.org/way/995869233
- 西校区原始提取框：117.985,36.803,118.006,36.817。
- 东校区原始提取框：118.025,36.800,118.055,36.825。
- 原始接口：`https://www.openstreetmap.org/api/0.6/map?bbox=<提取框>`。
- 原始文件：`data/west.osm`、`data/east.osm`；派生文件：`data/campus.js`、`data/campus.json`。

提取算法读取真实边界 way，以分段中点是否位于校区多边形内筛选道路，保留 OSM 节点编号、way分段编号和名称。长度由当地经纬度近似比例计算。未记录名称的道路按其 highway 类型显示“校园道路/校园支路/步行道”等通用名称，这不是学校官方路名。建筑轮廓取自OSM，地点坐标为标注点或多边形中心的近似值；不保证入口位置。代码根据 highway 和 bicycle/motor_vehicle/oneway 属性进行基本出行方式过滤，并非完整的OSM路由权限解释器。

地图上已显示署名。派生数据库与原始快照随工程公开提供；重新分发或公开使用派生数据库应遵循ODbL条款。代码的MIT许可不替代地图数据库许可。东校区快照内建筑数据缺失，不代表东校区没有建筑。

## 2 UCI Bike Sharing Dataset

- 作者：Hadi Fanaee-T、João Gama。
- 数据页：https://archive.ics.uci.edu/dataset/275/bike+sharing+dataset
- DOI：https://doi.org/10.24432/C5W894
- 原始包：https://archive.ics.uci.edu/static/public/275/bike+sharing+dataset.zip
- 许可：CC BY 4.0；https://creativecommons.org/licenses/by/4.0/
- 原始包SHA256：`b70182d0d0508e9abbb79306ce5c0cec34869000f8220175ac83d11dbe845401`。
- 原始记录：hour.csv，17,379条，2011–2012年美国华盛顿共享单车租借记录。
- 处理：按hr分组，求cnt均值，以24组中的最大均值归一化。
- 派生统计：`data/uci-demand.json`及同源的JavaScript模块`data/uci-demand.js`，保留作者、许可、来源、记录数和哈希。
- 复现：`python scripts/fetch_uci.py`。

工程只把异地公开骑行需求的小时变化形状作为演示输入，再加入明确声明的校园高峰假设与道路种子。不能将其当作山东理工大学的流量观测，不能推断校园预测准确率。管理端回测曲线为合成流程演示，没有独立的本校真实验证集。

## 3 Open-Meteo 天气

- 服务：https://open-meteo.com/
- 接口文档：https://open-meteo.com/en/docs
- 许可说明：https://open-meteo.com/en/terms
- 天气数据按服务的CC BY 4.0等适用条款署名；免费API适用范围与调用限额以提供方条款为准。
- 仅在用户启用本地服务后查询公开校区中心点，不发送用户实时位置。
- 失败时显示“天气暂不可用”，不生成假天气。

天气数据由Open-Meteo服务返回，属于模型或网格天气资料，不能宣称是校内气象站实测值。

## 4 本机数据与演示假设

事件文字、选点与照片由测试用户主动填写；不会预置成真实用户上报。拥堵指数、道路风险权重、交通预测与管理端误差演示均由项目代码生成并在界面标明。代码未接入学校监控、课表、个人轨迹或未经授权的账号数据。

## 1.1.0更新

用户端与管理端仅使用原西校区地图，历史东校区资料保留作原始来源记录，不提供切换入口。地图采用矢量图像与相机变换显示；位置和朝向标记为单独图层。

天气主连接已改为中国天气网淄博公开天气页https://www.weather.com.cn/weather1d/101120301.shtml，按页面结构提取当前资料及分时预报并缓存；旧Open-Meteo接口保留为兼容接口，主要页面不再自动请求。中国天气网的文章、图片与整页内容未随项目再分发。正式/商业应用应按其条款取得数据使用授权。

随附Windows x64 Node.js v24.19.0用于管理端本机启动，运行时版权及第三方许可全文见runtime/LICENSE-Node.txt。

## 1.2.0文档解析依赖

随附pdfjs-dist5.6.205（Mozilla PDF.js，Apache-2.0），CMap/标准字体及@napi-rs/canvas0.1.100的Windows x64运行依赖。具体版本、来源及许可保存在server/vendor对应目录。PDF解析不调用第三方OCR服务，原PDF不持久化。
