@echo off
chcp 65001 >nul
cd /d "%~dp0"
echo ============================================================
echo   智行校园 · 公网管理端一键启动器（评委跨网络访问专用）
echo ============================================================
echo.
if not exist "%~dp0runtime\node.exe" (
  echo [错误] 缺少 runtime\node.exe，请完整解压项目后再运行。
  pause
  exit /b 1
)
set CAMPUS_HOST=0.0.0.0
set TRUST_PROXY=1
set CAMPUS_ALLOW_PUBLIC_HOST=1
set CAMPUS_NO_BROWSER=1
echo [1/2] 正在后台启动智行校园服务（端口 3219）...
start "" /b "%~dp0runtime\node.exe" "%~dp0server\launch.js"
timeout /t 2 /nobreak >nul

echo [2/2] 正在检测公网穿透工具（cloudflared）...
where cloudflared >nul 2>nul
if %errorlevel%==0 (
  echo 已检测到 cloudflared，正在生成公网 HTTPS 网址...
  echo 请在下方输出中找到 https://xxxx.trycloudflare.com 并在末尾加上 /admin/ 发给评委！
  echo 例如：https://xxxx.trycloudflare.com/admin/
  echo （保持此窗口不要关闭，评委即可在任意网络、任意手机或电脑浏览器中打开管理端）
  echo.
  cloudflared tunnel --url http://127.0.0.1:3219
) else (
  echo 未检测到 cloudflared。
  echo.
  echo 您有两种方式获得「任意网络都能打开的公网管理端网址」：
  echo   方式 A（推荐，永久公网网址，关电脑也能访问）：
  echo     将本项目上传至 GitHub 后，使用 Render / Zeabur / Railway 一键导入（已内置 render.yaml 与 Dockerfile），
  echo     几分钟即可获得永久公网 HTTPS 管理端网址：https://你的域名/admin/
  echo.
  echo   方式 B（本机临时公网演示）：
  echo     在 PowerShell 运行 winget install Cloudflare.cloudflared 安装后，再次双击本脚本即可自动生成公网网址。
  echo.
  pause
)
