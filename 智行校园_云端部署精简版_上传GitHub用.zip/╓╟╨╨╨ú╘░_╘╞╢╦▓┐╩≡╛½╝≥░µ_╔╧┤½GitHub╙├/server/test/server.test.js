'use strict';
const { test } = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs/promises');
const path = require('node:path');
const http = require('node:http');
const { createServer, BODY_LIMIT } = require('../index');

const example = { type: '道路拥堵', location: '图书馆东门', description: '上下课时段车辆排队', reporter: '测试同学', reporterId: 'local-1', campus: '东校区' };
const liveWeather = { current: { time: '2026-10-16T18:15', temperature_2m: 21.3, weather_code: 2, wind_speed_10m: 8.4, is_day: 1 } };
async function fixture(t, options = {}) {
  await fs.mkdir(path.join(__dirname, '.tmp'), { recursive: true });
  const temp = await fs.mkdtemp(path.join(__dirname, '.tmp', 'zhixing-server-'));
  const storeFile = path.join(temp, 'events.json'); const dataDir = path.join(temp, 'data');
  await fs.mkdir(dataDir);
  const server = await createServer({authRequired:false, storeFile, dataDir, fetcher: async () => ({ ok: true, json: async () => liveWeather }), ...options });
  await new Promise(resolve => server.listen(0, '127.0.0.1', resolve));
  const base = `http://127.0.0.1:${server.address().port}`;
  t.after(async () => { server.closeAllConnections(); await new Promise(resolve => server.close(resolve)); await fs.rm(temp, { recursive: true, force: true }); });
  const request = async (route, method = 'GET', body, headers = {}) => {
    const response = await fetch(base + route, { method, headers: { 'Content-Type': 'application/json', ...headers }, ...(body === undefined ? {} : { body: JSON.stringify(body) }) });
    return { status: response.status, headers: response.headers, data: response.status === 204 ? null : await response.json() };
  };
  return { request, base, storeFile, dataDir, temp };
}
test('events: empty installation, create, progress sync, filters and persistence after reopen', async t => {
  const f = await fixture(t);
  assert.deepEqual((await f.request('/api/events')).data.events, []);
  const created = await f.request('/api/events', 'POST', { ...example, photos: ['wxfile://tmp/test.jpg'], latitude: 36.67, longitude: 117.12 });
  assert.equal(created.status, 201);
  const event = created.data.event;
  assert.equal(event.status, 'pending'); assert.equal(event.history.length, 1);
  const changed = await f.request(`/api/events/${event.id}`, 'PATCH', { status: 'processing', progress: '已安排人员现场核查' });
  assert.equal(changed.status, 200); assert.equal(changed.data.event.history.length, 2);
  assert.equal((await f.request('/api/events?status=unprocessed&reporterId=local-1')).data.events[0].progress, '已安排人员现场核查');
  await f.request(`/api/events/${event.id}`, 'PATCH', { status: 'resolved', progress: '道路已恢复通行' });
  assert.equal((await f.request('/api/events?status=unprocessed')).data.total, 0);
  assert.equal((await f.request('/api/events?status=processed')).data.total, 1);
  assert.equal((await f.request('/api/events?reporterId=someone-else')).data.total, 0);
  const disk = JSON.parse(await fs.readFile(f.storeFile, 'utf8'));
  assert.equal(disk.events[0].history.length, 3);
  const reopened = await createServer({authRequired:false, storeFile: f.storeFile });
  await new Promise(resolve => reopened.listen(0, '127.0.0.1', resolve));
  try {
    const response = await fetch(`http://127.0.0.1:${reopened.address().port}/api/events`);
    assert.equal((await response.json()).events[0].status, 'resolved');
  } finally { reopened.closeAllConnections(); await new Promise(resolve => reopened.close(resolve)); }
});
test('concurrent event creation and updates do not lose writes; rejected patch does not poison queue', async t => {
  const f = await fixture(t);
  const created = await Promise.all(Array.from({ length: 18 }, (_, i) => f.request('/api/events', 'POST', { ...example, location: `路段${i}` })));
  assert.ok(created.every(r => r.status === 201));
  assert.equal((await f.request('/api/events')).data.total, 18);
  const id = created[0].data.event.id;
  assert.equal((await f.request(`/api/events/${id}`, 'PATCH', { status: 'invalid' })).status, 400);
  await Promise.all(Array.from({ length: 10 }, (_, i) => f.request(`/api/events/${id}`, 'PATCH', { progress: `进度${i}` })));
  const saved = (await f.request('/api/events')).data.events.find(e => e.id === id);
  assert.equal(saved.history.length, 11);
  assert.equal(JSON.parse(await fs.readFile(f.storeFile, 'utf8')).events.length, 18);
});
test('input validation rejects unknown fields, invalid types, photos and coordinates', async t => {
  const f = await fixture(t);
  const bad = [null, [], 'bad', { ...example, type: '其他' }, { ...example, description: '字'.repeat(51) }, { ...example, description: ' ' },
    { ...example, campus: '北校区' }, { ...example, location: 5 }, { ...example, reporter: [] }, { ...example, status: 'resolved' },
    { ...example, photos: ['javascript:alert(1)'] }, { ...example, photos: ['https://example.test/photo'].flatMap(x => [x,x,x,x]) },
    { ...example, latitude: 91, longitude: 180 }, { ...example, latitude: 36 }, { ...example, latitude: '36', longitude: 117 }];
  for (const body of bad) assert.equal((await f.request('/api/events', 'POST', body)).status, 400, JSON.stringify(body));
  const good = await f.request('/api/events', 'POST', { ...example, description: '🚲'.repeat(50) });
  assert.equal(good.status, 201);
  for (const patch of [{}, { progress: '' }, { progress: '字'.repeat(201) }, { status: 'constructor' }, { description: '修改' }]) {
    assert.equal((await f.request(`/api/events/${good.data.event.id}`, 'PATCH', patch)).status, 400);
  }
  assert.equal((await f.request('/api/events/missing', 'PATCH', { status: 'resolved' })).status, 404);
  assert.equal((await f.request('/api/events?status=bad')).status, 400);
});
test('JSON errors: malformed JSON, unsupported media type, body limit with and without Content-Length', async t => {
  const f = await fixture(t);
  const malformed = await fetch(f.base + '/api/events', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: '{' });
  assert.equal(malformed.status, 400); assert.equal((await malformed.json()).error.code, 'INVALID_JSON');
  const media = await fetch(f.base + '/api/events', { method: 'POST', body: '{}' });
  assert.equal(media.status, 415); assert.equal((await media.json()).error.code, 'UNSUPPORTED_MEDIA_TYPE');
  const oversized = await f.request('/api/events', 'POST', { ...example, description: 'x'.repeat(BODY_LIMIT) });
  assert.equal(oversized.status, 413); assert.equal(oversized.data.error.code, 'BODY_TOO_LARGE');
  const streamed = await new Promise((resolve, reject) => {
    const req = http.request(f.base + '/api/events', { method: 'POST', headers: { 'Content-Type': 'application/json' } }, res => {
      let body = ''; res.on('data', chunk => body += chunk); res.on('end', () => resolve({ status: res.statusCode, body: JSON.parse(body) }));
    });
    req.on('error', reject); req.write('x'.repeat(33000)); req.end('x'.repeat(33000));
  });
  assert.equal(streamed.status, 413); assert.equal(streamed.body.error.code, 'BODY_TOO_LARGE');
  assert.equal((await f.request('/api/events', 'DELETE')).status, 405);
  assert.equal((await f.request('/api/nope')).status, 404);
  assert.equal((await f.request('/api/events')).status, 200);
});
test('local CORS preflight and non-local origin denial', async t => {
  const f = await fixture(t);
  for (const origin of ['http://localhost:5173', 'http://127.0.0.1:3219', 'http://[::1]:3000', 'null']) {
    const r = await f.request('/api/events', 'OPTIONS', undefined, { Origin: origin });
    assert.equal(r.status, 204); assert.equal(r.headers.get('access-control-allow-origin'), origin);
    assert.match(r.headers.get('access-control-allow-methods'), /PATCH/);
  }
  for (const origin of ['https://malicious.test', 'http://localhost.evil.test', 'http://localhost:3219/']) {
    const r = await f.request('/api/events', 'POST', example, { Origin: origin });
    assert.equal(r.status, 403); assert.equal(r.headers.get('access-control-allow-origin'), null);
  }
  assert.equal((await f.request('/api/events')).data.total, 0);
});
test('traffic is explicitly synthetic; metrics match aligned series; selectors validated', async t => {
  const f = await fixture(t);
  const east = (await f.request('/api/traffic')).data;
  assert.equal(east.synthetic, true); assert.equal(east.source, 'synthetic'); assert.match(east.metrics.label, /合成/);
  const errors = east.series.map(p => p.predicted - p.actual);
  const round = n => Math.round(n * 100) / 100;
  assert.equal(east.metrics.mae, round(errors.reduce((s, x) => s + Math.abs(x), 0) / errors.length));
  assert.equal(east.metrics.rmse, round(Math.sqrt(errors.reduce((s, x) => s + x*x, 0) / errors.length)));
  assert.equal(east.metrics.mape, round(east.series.reduce((s, p) => s + Math.abs((p.predicted-p.actual)/p.actual), 0) / errors.length * 100));
  const west = (await f.request('/api/traffic?campus=west&horizon=30')).data;
  assert.equal(west.campus, 'west'); assert.equal(west.horizon, 30); assert.notDeepEqual(east.series, west.series);
  assert.equal((await f.request('/api/traffic?campus=西校区&horizon=5')).status, 200);
  assert.equal((await f.request('/api/traffic?horizon=7')).status, 400);
  assert.equal((await f.request('/api/traffic?campus=north')).status, 400);
});
test('optional campus module supplies road labels without changing synthetic claims', async t => {
  const f = await fixture(t);
  await fs.writeFile(path.join(f.dataDir, 'campus.js'), "module.exports = { campuses: { east: {roads: [{name: '共享校园路'}]} } };\n");
  const server = await createServer({authRequired:false, storeFile: path.join(f.temp, 'optional-events.json'), dataDir: f.dataDir });
  await new Promise(resolve => server.listen(0, '127.0.0.1', resolve));
  try {
    const data = await (await fetch(`http://127.0.0.1:${server.address().port}/api/traffic`)).json();
    assert.equal(data.roads[0].name, '共享校园路'); assert.equal(data.synthetic, true);
  } finally { server.closeAllConnections(); await new Promise(resolve => server.close(resolve)); }
});
test('shared east/west map schema supplies unique road names and campus weather center', async t => {
  const f = await fixture(t);
  await fs.writeFile(path.join(f.dataDir, 'campus.js'), "module.exports = { east: { name: '东校区', center: {latitude:36.81,longitude:118.03}, edges:[{name:'东校门路'},{name:'东校门路'},{name:'教学区路'}] } };\n");
  let upstreamUrl;
  const server = await createServer({authRequired:false, storeFile: path.join(f.temp, 'map-events.json'), dataDir: f.dataDir, fetcher: async url => { upstreamUrl = url; return { ok: true, json: async () => liveWeather }; } });
  await new Promise(resolve => server.listen(0, '127.0.0.1', resolve));
  try {
    const base = `http://127.0.0.1:${server.address().port}`;
    const traffic = await (await fetch(base + '/api/traffic')).json();
    assert.deepEqual(traffic.roads.map(r => r.name), ['东校门路', '教学区路']); assert.equal(traffic.synthetic, true);
    const weather = await (await fetch(base + '/api/weather?campus=east')).json();
    assert.equal(weather.locationLabel, '东校区'); assert.match(upstreamUrl, /latitude=36.81&longitude=118.03/);
  } finally { server.closeAllConnections(); await new Promise(resolve => server.close(resolve)); }
});
test('weather forwards validated coordinates, caches and returns timestamp and source', async t => {
  let calls = 0;
  const f = await fixture(t, { fetcher: async url => { calls++; assert.match(url, /latitude=36.5&longitude=117/); return { ok: true, json: async () => liveWeather }; } });
  const [a, b] = await Promise.all([f.request('/api/weather?latitude=36.5&longitude=117'), f.request('/api/weather?latitude=36.5&longitude=117')]);
  assert.equal(a.data.available, true); assert.equal(b.data.temperature, 21.3); assert.equal(calls, 1);
  assert.equal(a.data.observedAt, '2026-10-16T18:15+08:00'); assert.equal(a.data.source, 'Open-Meteo');
  await f.request('/api/weather?latitude=36.5&longitude=117'); assert.equal(calls, 1);
  for (const query of ['latitude=100&longitude=0', 'latitude=abc&longitude=0', 'latitude=0', 'latitude=&longitude=0']) assert.equal((await f.request(`/api/weather?${query}`)).status, 400);
});
test('weather network, upstream, malformed response and timeout failures degrade gracefully', async t => {
  for (const fetcher of [async () => { throw new Error('offline'); }, async () => ({ ok: false }), async () => ({ ok: true, json: async () => ({}) }), async () => new Promise(() => {})]) {
    await t.test('unavailable weather', async t => {
      const f = await fixture(t, { fetcher, weatherTimeoutMs: 25 });
      const r = await f.request('/api/weather');
      assert.equal(r.status, 200); assert.equal(r.data.available, false); assert.equal(r.data.temperature, undefined);
      assert.equal((await f.request('/api/events')).status, 200);
    });
  }
});
test('static admin and safe JSON serving reject traversal and symlink escape', async t => {
  const f = await fixture(t);
  await fs.writeFile(path.join(f.dataDir, 'roads.json'), '{"roads":[]}');
  await fs.writeFile(path.join(f.temp, 'private.json'), '{"secret":true}');
  assert.equal((await f.request('/data/roads.json')).status, 200);
  for (const route of ['/data/%2e%2e%2fprivate.json', '/data/%252e%252e%252fprivate.json', '/data/campus.js', '/data/.hidden.json', '/admin/../server/index.js', '/data/%00.json']) {
    const response = await fetch(f.base + route); assert.equal(response.status, 404, route);
    assert.ok((await response.json()).error);
  }
  // File symlinks may require Developer Mode on Windows; junctions do not.
  await fs.symlink(f.temp, path.join(f.dataDir, 'outside'), 'junction');
  assert.equal((await f.request('/data/outside%2fprivate.json')).status, 404);
  const html = await fetch(f.base + '/admin/');
  assert.equal(html.status, 200); assert.match(html.headers.get('content-type'), /text\/html/); assert.match(await html.text(), /智行校园/);
  const css = await fetch(f.base + '/admin/styles.css'); assert.equal(css.status, 200);
  assert.match(css.headers.get('content-type'), /text\/css/);
  assert.equal((await fetch(f.base + '/admin/app.js')).status, 200);
});
test('corrupt persistence is preserved and startup fails', async t => {
  const f = await fixture(t);
  const corrupt = path.join(f.temp, 'corrupt.json'); await fs.writeFile(corrupt, '{broken');
  await assert.rejects(createServer({authRequired:false, storeFile: corrupt }), /原文件已保留/);
  assert.equal(await fs.readFile(corrupt, 'utf8'), '{broken');
});
