const store=require('../../utils/store'),campus=require('../../data/campus').west,geo=require('../../utils/geo'),router=require('../../utils/router'),search=require('../../utils/search'),live=require('../../utils/location'),ui=require('../../utils/page'),memory=require('../../utils/preferences');
const pad=n=>('0'+n).slice(-2);
Page({
 data:{campus:'west',queryFrom:'',queryTo:'',from:null,to:null,mode:'walk',modes:[{id:'walk',name:'步行'},{id:'bike',name:'骑行'},{id:'car',name:'驾车'}],preference:'fast',preferences:[{id:'fast',name:'更快'},{id:'quiet',name:'少拥堵'},{id:'safe',name:'更安全'}],date:'',depart:'',suggestions:[],focus:'',searching:false,picking:'',routes:[],routePoints:[],selectedRoute:0,road:null,selectedEdge:'',showSteps:false,location:null,heading:0,routeFavorite:false,roadFavorite:false,placeFavorite:false,memoryHint:'',frequentRoutes:[],used:false,events:[]},
 onLoad(q={}){
  const d=new Date(),settings=memory.settings();
  this.setData({mode:settings.mode||'walk',preference:settings.preference||'fast',depart:pad(d.getHours())+':'+pad(d.getMinutes()),date:d.getFullYear()+'-'+pad(d.getMonth()+1)+'-'+pad(d.getDate())});
  this.refreshMemory();
  if(q.to){const p=search.places.find(p=>p.id===q.to)||(store.read().placeFavorites||[]).find(p=>p.id===q.to);if(p)this.applyPoint('to',p);}
  if(q.dining){const draft=require('../../utils/dining').takeRouteDraft();if(draft){if(draft.from)this.applyPoint('from',draft.from);this.setData({mode:draft.mode,date:draft.date,depart:draft.depart});if(draft.from&&this.data.to)this.plan();}}
  if(q.history!==undefined){const saved=memory.summary().history[Number(q.history)];if(saved)this.loadSaved(saved);}
  if(q.favorite){const saved=(store.read().routeFavorites||[]).find(x=>x.key===q.favorite);if(saved)this.loadSaved(saved);}
  if(q.edge){const edge=campus.edges.find(x=>x.id===q.edge);if(edge){const a=campus.nodes[edge.a],b=campus.nodes[edge.b],from={id:edge.a,node:edge.a,name:search.clean(edge.name)+'起点',longitude:a[0],latitude:a[1]},to={id:edge.b,node:edge.b,name:search.clean(edge.name)+'终点',longitude:b[0],latitude:b[1]};this.loadSaved({key:[edge.a,edge.b,this.data.mode].join('|'),from,to,mode:this.data.mode,edges:[edge.id]});this.setData({showSteps:true});}}
 },
 onShow(){this._visible=true;this.refreshMemory();this.setData({events:store.trafficEvents()});if(this.data.routes.length)this.plan();if(store.read().online&&require('../../utils/account').current())require('../../utils/api').refreshIncidents().then(()=>{if(!this._visible)return;this.setData({events:store.trafficEvents()});if(this.data.routes.length)this.plan();}).catch(()=>{});},
 onReady(){const r=this.data.routes[this.data.selectedRoute],readyMap=this.selectComponent&&this.selectComponent('#route-map');if(r&&readyMap)readyMap.fitRoute(r.points);const edge=campus.edges.find(e=>e.id===this.data.selectedEdge),map=this.selectComponent&&this.selectComponent('#route-map');if(edge&&map){const a=campus.nodes[edge.a],b=campus.nodes[edge.b];map.centerOn({longitude:(a[0]+b[0])/2,latitude:(a[1]+b[1])/2});}},
 onHide(){this._visible=false;live.stop(this);},onUnload(){this.onHide();},
 refreshMemory(){const s=memory.summary(),owner=store.read().preferenceOwner;if(this._owner&&owner!==this._owner){this.clearRoutes();const settings=memory.settings();this.setData({from:null,to:null,queryFrom:'',queryTo:'',mode:settings.mode||'walk',preference:settings.preference||'fast'});}this._owner=owner;this.setData({frequentRoutes:s.enabled?s.history:[],memoryHint:!s.enabled?'偏好记忆已关闭':s.settingText?'已恢复本机偏好：'+s.settingText:'选择出行方式并使用路线后，会记住你的偏好'});},
 clearRoutes(){this.setData({routes:[],routePoints:[],road:null,selectedEdge:'',used:false});},
 input(e){const field=e.currentTarget.dataset.field,value=e.detail.value;this.clearRoutes();this.setData({[field==='from'?'queryFrom':'queryTo']:value,[field]:null,focus:field,suggestions:search.search(value),searching:!!value});},
 focusInput(e){const field=e.currentTarget.dataset.field,q=field==='from'?this.data.queryFrom:this.data.queryTo;this.setData({focus:field,searching:!!q,suggestions:search.search(q)});},
 confirmInput(e){const field=e.currentTarget.dataset.field||this.data.focus,value=field==='from'?this.data.queryFrom:this.data.queryTo,hits=search.search(value);if(!hits.length)return ui.toast('未找到地点，试试楼号、简称或地标名称');this.applyPoint(field,hits[0]);},
 choose(e){const p=this.data.suggestions[Number(e.currentTarget.dataset.index)];if(p)this.applyPoint(this.data.focus,p);},
 applyPoint(field,input){const p=Object.assign({},input);if(!p.node)p.node=geo.nearest(campus,p).id;this.clearRoutes();this.setData({[field]:p,[field==='from'?'queryFrom':'queryTo']:p.name,suggestions:[],focus:'',searching:false,picking:'',placeFavorite:field==='to'?(store.read().placeFavorites||[]).some(x=>x.id===(p.id||p.node)):this.data.placeFavorite});const map=this.selectComponent&&this.selectComponent('#route-map');if(map)map.centerOn(p);},
 pickStart(e){this.setData({picking:e.currentTarget.dataset.field,searching:false});ui.toast('轻点地图设置'+(this.data.picking==='from'?'起点':'终点'));},
 mapPick(e){if(!this.data.picking)return;const p=e.detail;if(!geo.inCampus(campus,p))return ui.toast('请选择校园范围内地点');const n=geo.nearest(campus,p);if(n.distance>180)return ui.toast('距离道路较远，请靠近道路选点');const nearest=search.places.slice().sort((a,b)=>geo.distance(a,p)-geo.distance(b,p))[0];this.applyPoint(this.data.picking,Object.assign({},p,{node:n.id,name:nearest&&geo.distance(nearest,p)<100?nearest.name+'附近':'地图选点'}));},
 async locate(){try{const p=await live.start(this);if(!geo.inCampus(campus,p))return ui.toast('当前位置不在校园范围内，请输入校园内起点');this.applyPoint('from',Object.assign({},p,{node:geo.nearest(campus,p).id,name:'我的位置'}));}catch(e){ui.toast(e);}},
 swap(){const {from,to,queryFrom,queryTo}=this.data;this.clearRoutes();this.setData({from:to,to:from,queryFrom:queryTo,queryTo:queryFrom});},
 mode(e){const value=e.currentTarget.dataset.id;if(!memory.modes[value])return;memory.rememberSetting('mode',value);this.clearRoutes();this.setData({mode:value});this.refreshMemory();},
 time(e){this.clearRoutes();this.setData({depart:e.detail.value});},
 dateChange(e){this.clearRoutes();this.setData({date:e.detail.value});},
 preference(e){const value=e.currentTarget.dataset.id;if(!memory.strategies[value])return;memory.rememberSetting('preference',value);this.setData({preference:value});this.refreshMemory();if(this.data.routes.length)this.plan();},
 routeKey(){const d=this.data;return d.from&&d.to?[d.from.id||d.from.node,d.to.id||d.to.node,d.mode].join('|'):'';},
 plan(){try{
  for(const field of ['from','to']){if(this.data[field])continue;const query=this.data[field==='from'?'queryFrom':'queryTo'],hits=search.search(query);if(!hits.length)throw new Error('请输入并搜索有效的'+(field==='from'?'起点':'终点'));this.setData({[field]:hits[0],[field==='from'?'queryFrom':'queryTo']:hits[0].name});}
  const d=this.data;if(d.from.node===d.to.node)throw new Error('起点和终点距离太近，请换一个地点');
  const routeMemory=Object.assign({},memory.memory(),{selectedFavorite:this._savedRoute});
  const routes=router.route(campus,d.from,d.to,d.mode,d.preference,new Date(d.date+'T'+d.depart+':00+08:00'),store.trafficEvents(),routeMemory).map(r=>Object.assign({},r,{roads:r.roads.split(' → ').map(search.clean).join(' → '),segments:r.segments.map(s=>Object.assign({},s,{name:search.clean(s.name),status:s.index>72?'拥堵':s.index>45?'缓行':'畅行'}))}));
  this._recorded=new Set();this.setData({routes,routePoints:routes[0].points,selectedRoute:0,picking:'',searching:false,road:null,selectedEdge:'',showSteps:false,used:false,routeFavorite:(store.read().routeFavorites||[]).some(x=>x.key===this.routeKey())});
  const map=this.selectComponent&&this.selectComponent('#route-map');if(map)map.fitRoute(routes[0].points);
 }catch(e){this.clearRoutes();ui.toast(e);}},
 selectRoute(e){this.setRoute(Number(e.currentTarget.dataset.index));},
 setRoute(index){const r=this.data.routes[index];if(!r)return;this.setData({selectedRoute:index,routePoints:r.points,road:null,selectedEdge:'',used:!!(this._recorded&&this._recorded.has(r.edges.join(',')))});},
 routeTap(e){this.setRoute(e.detail.index);this.setData({showSteps:true});},
 useRoute(){this.setData({showSteps:true});const d=this.data,r=d.routes[d.selectedRoute];if(!r)return;this._recorded=this._recorded||new Set();const id=r.edges.join(',');if(this._recorded.has(id))return ui.toast('本次已使用此路线');const saved=memory.record(d.from,d.to,d.mode,d.preference,r);this._recorded.add(id);this.setData({used:true});this.refreshMemory();ui.toast(saved?'已使用路线并记住你的选择':'已选择路线，偏好记忆已关闭');},
 loadSaved(saved){this._savedRoute=saved;const resolve=field=>{const id=saved[field+'Id'];const p=saved[field]||search.places.find(p=>p.id===id)||(campus.nodes[id]?{id,node:id,name:saved[field+'Name'],longitude:campus.nodes[id][0],latitude:campus.nodes[id][1]}:null);return p&&Object.assign({},p,{name:p.name==='我的位置'?'上次出发位置':p.name});};const from=resolve('from'),to=resolve('to');if(!from||!to)return ui.toast('旧记录缺少坐标，请重新搜索起终点');this.applyPoint('from',from);this.applyPoint('to',to);this.setData({mode:saved.mode||this.data.mode,preference:saved.preference||this.data.preference});this.plan();},
 repeat(e){const saved=this.data.frequentRoutes[Number(e.currentTarget.dataset.index)];if(saved)this.loadSaved(saved);},
 incidentTap(e){wx.showModal({title:e.detail.type,content:e.detail.description+'；'+e.detail.reason,showCancel:false});},
 roadTap(e){const road=e.detail,value=road.value||0;this.setData({road:Object.assign({},road,{index:Math.round(value*100),status:value>.72?'拥堵':value>.45?'缓行':'畅行',name:search.clean(road.name)}),roadFavorite:(store.read().roadFavorites||[]).some(x=>x.id===road.id),selectedEdge:road.id});},
 step(e){const r=this.data.routes[this.data.selectedRoute],segment=r.segments[Number(e.currentTarget.dataset.index)];this.setData({selectedEdge:segment.id,road:Object.assign({},segment,{value:segment.index/100}),roadFavorite:(store.read().roadFavorites||[]).some(x=>x.id===segment.id)});const edge=campus.edges.find(e=>e.id===segment.id);if(edge){const n=campus.nodes[edge.a],map=this.selectComponent&&this.selectComponent('#route-map');if(map)map.centerOn({longitude:n[0],latitude:n[1]});}},
 closeRoad(){this.setData({road:null,selectedEdge:''});},toggleSteps(){this.setData({showSteps:!this.data.showSteps});},
 toggleRouteFavorite(){const d=this.data,r=d.routes[d.selectedRoute];if(!r)return;const active=store.toggleFavorite('route',{key:this.routeKey(),fromId:d.from.id||d.from.node,toId:d.to.id||d.to.node,from:d.from,to:d.to,fromName:d.from.name,toName:d.to.name,mode:d.mode,preference:d.preference,edges:r.edges,roads:r.roads});this.setData({routeFavorite:active});ui.toast(active?'已收藏路线':'已取消收藏');},
 toggleRoadFavorite(){if(!this.data.road)return;const active=store.toggleFavorite('road',{id:this.data.road.id,name:this.data.road.name});this.setData({roadFavorite:active});ui.toast(active?'已收藏偏好路段':'已取消收藏');},
 togglePlaceFavorite(){const p=this.data.to;if(!p)return;const active=store.toggleFavorite('place',Object.assign({},p,{id:p.id||p.node}));this.setData({placeFavorite:active});ui.toast(active?'已收藏目的地':'已取消收藏');}
});

