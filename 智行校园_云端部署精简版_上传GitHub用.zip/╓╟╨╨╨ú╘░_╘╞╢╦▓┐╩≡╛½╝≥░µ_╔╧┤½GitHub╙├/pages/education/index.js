const store=require('../../utils/store'),api=require('../../utils/api'),education=require('../../utils/education'),schedule=require('../../utils/schedule'),account=require('../../utils/account');
Page({
 data:{endpoint:'',token:'',authorized:false,busy:false,message:'',courses:[],semesterName:''},
 onLoad(q={}){this.setData({semesterName:education.termKey(q.semesterName||store.read().semesterName)||education.currentTerm()});wx.showModal({title:'校园接口授权提醒',content:'需获得校园接口授权才可导入。请向学校获取课表API地址及个人访问凭证，门户网址和学号密码不能替代授权接口。',showCancel:false,confirmText:'我知道了'});},
 field(e){const key=e.currentTarget.dataset.field;if(['endpoint','token'].includes(key))this.setData({[key]:e.detail.value});},
 consent(e){this.setData({authorized:(e.detail.value||[]).includes('authorized')});},
 async fetchCourses(){
  if(this.data.busy)return;
  this.setData({message:'',courses:[]});this._courses=null;
  if(!this.data.authorized){this.setData({message:'需获得校园接口授权才可导入，请先确认已获授权。'});return;}
  let url;try{url=require('../../utils/education-api').validate(this.data.endpoint);}catch(error){this.setData({message:error.message});return;}
  if(!store.read().online||!account.current()){this.setData({message:'请先连接校园服务并登录小程序服务账号；这与学校账号是独立的。'});return;}
  this.setData({busy:true});
  try{const r=await api.request('/api/integrations/education','POST',{url,token:this.data.token,authorized:true}),courses=schedule.parse(JSON.stringify(r.courses),'json');if(!courses.length)throw new Error('接口未返回有效课程');this._courses=courses;this.setData({courses,message:'已读取'+courses.length+'条上课安排，请核对后确认导入。'});}
  catch(error){this.setData({message:error.message});}
  finally{this.setData({busy:false,token:''});}
 },
 confirm(){if(!this._courses||this.data.busy)return;const courses=this._courses;wx.showModal({title:'确认导入课表',content:'将'+courses.length+'条课程保存到'+education.termLabel(this.data.semesterName)+'，替换该学期现有课程。',success:r=>{if(!r.confirm)return;try{education.saveImport({courses,semester:this.data.semesterName});this._courses=null;this.setData({courses:[],message:'授权课表已导入'});wx.navigateBack({delta:1});}catch(error){this.setData({message:error.message});}}});},
 settings(){wx.navigateTo({url:'/pages/settings/index'});},
 onUnload(){this._courses=null;this.data.token='';}
});
