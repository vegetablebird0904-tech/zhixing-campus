const store = require('../../utils/store');
const account = require('../../utils/account');
const api = require('../../utils/api');
const connection = require('../../utils/connection');

Page({
  data: {mode:'login', username:'', password:'', name:'', phone:'', avatar:'', consent:false,
    busy:false, checking:false, loggedIn:false, user:null, oldPassword:'', newPassword:'', message:'',
    online:false, endpoint:'', connected:false, wechatEnabled:false, registration:true, connectionText:'尚未检测服务', connectionError:'', connectionErrorCode:'',phone:false},
  onLoad() {
    const p = store.profile();
    if (p) this.setData({name:p.name || '', avatar:p.avatar || '', phone:p.phone || ''});
    this.refresh();
  },
  onShow() {
    this.refresh();
    if (store.read().online) this.checkConnection();
  },
  refresh() {
    const a = account.current(), config = store.read();
    this.setData({loggedIn:!!a, user:a ? a.user : null, online:config.online, endpoint:config.endpoint,phone:connection.onPhone()});
  },
  async checkConnection() {
    if (this._connectionTask) return this._connectionTask;
    if (!store.read().online) {
      this.setData({connected:false, wechatEnabled:false, connectionText:'服务未启用，请先启用并检测'});
      return null;
    }
    this.setData({checking:true, connected:false, wechatEnabled:false, connectionText:'正在检测服务…',connectionError:'',connectionErrorCode:''});
    this._connectionTask = (async () => {
      try {
        const result = await connection.probe();
        this.refresh();
        this.setData({connected:true, wechatEnabled:!!result.status.loginMethods.wechat,
          registration:result.status.registration, connectionText:'已连接 · v' + result.health.version,
          endpoint:result.endpoint,connectionError:'',connectionErrorCode:''});
        return result;
      } catch (error) {
        const phoneLoopback=error.code==='PHONE_LOOPBACK';
        this.setData({connected:false, wechatEnabled:false, connectionText:phoneLoopback?'正在配置手机到电脑的局域网连接':error.code==='SERVICE_UNREACHABLE'?'电脑后台服务未启动':'服务连接未就绪', connectionError:error.message,connectionErrorCode:error.code||'', message:error.message});
        return null;
      } finally { this.setData({checking:false}); this._connectionTask = null; }
    })();
    return this._connectionTask;
  },
  async connect() {
    if (this.data.busy || this.data.checking) return;
    store.update({online:true});
    this.refresh();
    this.setData({message:''});
    await this.checkConnection();
  },
  field(e) { this.setData({[e.currentTarget.dataset.field]:e.detail.value}); },
  switchMode(e) { if (!this.data.busy) this.setData({mode:e.currentTarget.dataset.mode, password:'', message:''}); },
  name(e) { this.setData({name:e.detail.value}); },
  phone(e) { this.setData({phone:e.detail.value}); },
  consent(e) { this.setData({consent:e.detail.value.includes('yes')}); },
  avatar(e) { wx.saveFile({tempFilePath:e.detail.avatarUrl, success:r=>this.setData({avatar:r.savedFilePath}), fail:()=>wx.showToast({title:'头像保存失败',icon:'none'})}); },
  validate() {
    if (!this.data.consent) { wx.showToast({title:'请先同意隐私政策',icon:'none'}); return false; }
    return true;
  },
  save() {
    if (!this.validate()) return;
    store.update({profile:{name:this.data.name.trim() || '校园同行者', phone:this.data.phone, avatar:this.data.avatar, authType:'local'}});
    wx.showToast({title:'本机资料已保存'});
  },
  async submit() {
    if (this.data.busy || !this.validate()) return;
    if (!/^[A-Za-z0-9_]{4,32}$/.test(this.data.username)) return this.setData({message:'账号须为4至32位字母、数字或下划线'});
    if (this.data.password.length < 12 || this.data.password.length > 128 || !/[A-Za-z]/.test(this.data.password) || !/[0-9]/.test(this.data.password)) {
      return this.setData({message:'密码须为12至128位，至少包含字母和数字'});
    }
    if (!store.read().online) return this.setData({message:'请先点击“启用并检测服务”，无需配置微信AppSecret即可注册普通用户账号'});
    this.setData({busy:true,message:''});
    try {
      const ready = await this.checkConnection();
      if (!ready) return;
      const mode = this.data.mode === 'register' ? 'register' : 'login';
      if (mode === 'register' && !ready.status.registration) throw new Error('当前服务未开放自主注册，请联系管理员');
      const result = await api.request('/api/auth/' + mode, 'POST', {username:this.data.username, password:this.data.password, name:this.data.name || this.data.username});
      account.accept(result);
      this.setData({password:'', message:mode === 'register' ? '注册成功，已登录普通用户账号（无管理端权限）' : '登录成功'});
      this.refresh();
      wx.showToast({title:'登录成功'});
    } catch (error) { this.setData({message:error.message}); }
    finally { this.setData({busy:false}); }
  },
  async wechat() {
    if (this.data.busy || !this.validate()) return;
    if (!store.read().online) return this.setData({message:'请先启用并检测服务'});
    this.setData({busy:true,message:''});
    try {
      // Recheck before wx.login: never send a code to an unconfigured or old service.
      const ready = await this.checkConnection();
      if (!ready) return;
      if (!ready.status.loginMethods.wechat) throw new Error('服务未启用微信快捷登录，请直接使用账号密码注册或登录；天气和PDF均可正常使用，不需要AppSecret');
      const code = await new Promise((resolve,reject)=>wx.login({success:r=>r.code ? resolve(r.code) : reject(new Error('未取得微信凭证')), fail:r=>reject(new Error('微信登录失败：' + (r.errMsg || '请检查AppID')))}));
      const result = await api.request('/api/auth/wechat', 'POST', {code});
      account.accept(result);
      this.refresh();
      this.setData({message:'微信登录成功'});
    } catch (error) { this.setData({message:error.message}); }
    finally { this.setData({busy:false}); }
  },
  async changePassword() {
    if (this.data.busy) return;
    this.setData({busy:true,message:''});
    try {
      const result = await api.request('/api/auth/password','POST',{oldPassword:this.data.oldPassword,newPassword:this.data.newPassword});
      account.accept(result);
      this.setData({oldPassword:'',newPassword:'',message:'密码已修改，其他设备旧会话已失效'});
      this.refresh();
    } catch (error) { this.setData({message:error.message}); }
    finally { this.setData({busy:false}); }
  },
  async logout() {
    if (this.data.busy) return;
    this.setData({busy:true,message:''});
    try {
      await api.request('/api/auth/logout','POST',{});
      account.clear(); this.refresh();
      this.setData({message:'已退出，当前会话已撤销'});
    } catch (error) { this.setData({message:'服务端退出失败，请检查连接后重试：' + error.message}); }
    finally { this.setData({busy:false}); }
  },
  settings() { wx.navigateTo({url:'/pages/settings/index'}); },
  privacy() { wx.navigateTo({url:'/pages/info/index?type=privacy'}); }
});
