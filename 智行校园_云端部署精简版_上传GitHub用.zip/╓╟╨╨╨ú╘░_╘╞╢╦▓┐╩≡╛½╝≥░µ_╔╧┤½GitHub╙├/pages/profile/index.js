const store=require('../../utils/store'),memory=require('../../utils/preferences');
Page({
 data:{profile:null,count:0,done:0,online:false,placeFavorites:[],roadFavorites:[],routeFavorites:[],remembered:{enabled:true,history:[],settingText:'',historyCount:0}},
 onShow(){require('../../utils/page').tab(this,2);const es=store.events(),m=memory.summary();this.setData({profile:store.profile(),count:es.length,done:es.filter(e=>e.status==='processed').length,online:store.read().online,placeFavorites:m.favorites.places,roadFavorites:m.favorites.roads,routeFavorites:m.favorites.routes,remembered:m});},
 go(e){wx.navigateTo({url:'/pages/'+e.currentTarget.dataset.page+'/index'});},login(){wx.navigateTo({url:'/pages/login/index'});},
 info(e){wx.navigateTo({url:'/pages/info/index?type='+e.currentTarget.dataset.type});},settings(){wx.navigateTo({url:'/pages/settings/index'});},logout(){wx.navigateTo({url:'/pages/login/index'});},
 toggleMemory(e){store.update({memoryEnabled:!!e.detail.value});this.onShow();},
 clearMemory(){wx.showModal({title:'清除学习记录？',content:'将清除本账号在本设备的常用路线、使用次数及记住的出行设置。你主动收藏的地点、路段和路线会保留。',success:r=>{if(r.confirm){memory.clearHistory();this.onShow();}}});},
 repeat(e){wx.navigateTo({url:'/pages/route/index?history='+Number(e.currentTarget.dataset.index)});},
 openFavorite(e){const type=e.currentTarget.dataset.type,id=e.currentTarget.dataset.id;wx.navigateTo({url:'/pages/route/index?'+(type==='place'?'to':type==='road'?'edge':'favorite')+'='+encodeURIComponent(id)});},
 removeFavorite(e){store.removeFavorite(e.currentTarget.dataset.type,e.currentTarget.dataset.id);this.onShow();}
});

