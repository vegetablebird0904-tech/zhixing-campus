const store=require('../../utils/store'),endpoint=require('../../utils/endpoint'),account=require('../../utils/account'),connection=require('../../utils/connection');
Page({
  data:{online:false,endpoint:'',testing:false,message:'',loggedIn:false,username:'',lanEndpoints:[],phone:false},
  onLoad(){this.refreshAddress();},
  onShow(){if(!this._dirty)this.refreshAddress();const a=account.current();this.setData({loggedIn:!!a,username:a?a.user.username:'',lanEndpoints:connection.lanEndpoints(),phone:connection.onPhone()});},
  refreshAddress(){
    const s=store.read(),phone=connection.onPhone(),lanEndpoints=connection.lanEndpoints();
    let value=s.endpoint,message=this.data.message||'';
    // A loopback address belongs to the phone itself during real-device testing.
    // Show the launcher's current computer candidate in the field, but don't trust
    // or persist it until the normal health/project-identity probe succeeds.
    if(phone&&connection.loopback(value)){
      if(lanEndpoints.length){value=lanEndpoints[0];message='已发现电脑局域网地址候选；点击“自动检测并连接”验证后使用。';}
      else{value='';message='手机上的127.0.0.1只代表手机自身。请先在电脑当前项目运行“修复连接并启动.cmd”，重新编译后再自动检测。';}
    }
    if(value)try{value=endpoint.normalize(value);}catch(error){message=error.message;}
    this.setData({online:s.online,endpoint:value,lanEndpoints,phone,message});
  },
  toggle(e){this.setData({online:e.detail.value,message:'连接开关已修改，请保存设置'});},
  endpoint(e){this._dirty=true;this.setData({endpoint:e.detail.value});},
  save(){
    try{
      const value=endpoint.normalize(this.data.endpoint);
      const current=store.read(),previous=current.endpoint,phoneLoopback=connection.onPhone()&&connection.loopback(previous)&&connection.lanEndpoints().includes(value);
      let preservedAccount=current.account;
      if(value!==previous&&!phoneLoopback){account.clear();preservedAccount=null;}
      store.update({online:this.data.online,endpoint:value,autoLanEndpoint:value===previous?(current.autoLanEndpoint||''):'',lastServiceCheck:value===previous?(current.lastServiceCheck||''):'',account:preservedAccount});
      this._dirty=false;this.setData({endpoint:value});this.onShow();
      wx.showToast({title:'设置已保存'});return true;
    }catch(e){this.setData({message:e.message});wx.showToast({title:'请检查下方连接提示',icon:'none'});return false;}
  },
  async test(){
    if(this.data.testing)return;
    this.setData({online:true});
    if(!this.save())return;
    this.setData({testing:true,message:''});
    try{
      const r=await connection.recover();
      let message='服务连接成功 · v'+r.health.version+'。账号密码注册/登录可用，天气和PDF需要先登录。';
      message+=r.status.loginMethods.wechat?'微信快捷登录已启用。':'微信快捷登录未启用，不影响账号密码登录及天气/PDF。';
      if(!['0.0.0.0','::'].includes(r.health.listenHost))message+='当前只监听电脑本机，手机连接前须关闭该窗口，再运行“启动手机联调服务.cmd”。';
      this.setData({message});
    }catch(e){this.setData({message:e.message});}
    finally{this.setData({testing:false});}
  },
  async useLan(e){
    const selected=String(e.currentTarget.dataset.endpoint||'');
    try{this.data.endpoint=endpoint.normalize(selected);this.data.online=true;this.setData({endpoint:this.data.endpoint,online:true});await this.recover();}
    catch(error){this.setData({message:error.message});}
  },
  async recover(){if(this.data.testing)return;this.setData({online:true,testing:true,message:'正在无凭证检测本机与当前电脑联调地址…'});try{const r=await connection.recover();this._dirty=false;this.setData({endpoint:r.endpoint,online:true,message:'连接成功 · v'+r.health.version+'\n实际使用地址：'+r.endpoint+'\n后台服务已就绪，登录校园服务账号后即可使用天气和PDF。'});this.onShow();}catch(error){this.setData({message:error.message});}finally{this.setData({testing:false});}},
  login(){wx.navigateTo({url:'/pages/login/index'});}
});
