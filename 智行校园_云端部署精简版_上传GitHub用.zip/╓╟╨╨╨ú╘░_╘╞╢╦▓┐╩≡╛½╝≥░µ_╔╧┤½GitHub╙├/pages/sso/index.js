const loginUrl='https://authserver.sdut.edu.cn/authserver/login';
function schoolUrl(value){return typeof value==='string'&&/^https:\/\/(?:[a-z0-9-]+\.)*sdut\.edu\.cn(?:\/|$)/i.test(value);}
Page({
 data:{url:loginUrl,loadError:false,errorMessage:''},
 onLoad(q={}){let value='';try{value=q.url?decodeURIComponent(q.url):'';}catch{}if(schoolUrl(value))this.setData({url:value});},
 message(e){const values=e.detail&&e.detail.data||[],last=values[values.length-1]||{};if(last.ok===true&&typeof last.ticket==='string'&&/^[A-Za-z0-9_-]{24,128}$/.test(last.ticket)){wx.setStorageSync('sdut-sso-ticket',last.ticket);}else if(last.message)wx.showToast({title:last.message,icon:'none'});},
 failed(e){this.setData({loadError:true,errorMessage:e.detail&&e.detail.errMsg||'学校登录页未能加载，请检查网络及小程序业务域名配置。'});},
 retry(){this.setData({loadError:false,errorMessage:''});},
 copyUrl(){wx.setClipboardData({data:this.data.url});}
});

