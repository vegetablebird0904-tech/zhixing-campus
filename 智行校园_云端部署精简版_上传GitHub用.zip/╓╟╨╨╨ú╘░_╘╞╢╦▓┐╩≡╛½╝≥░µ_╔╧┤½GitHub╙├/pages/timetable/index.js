const store=require('../../utils/store'),schedule=require('../../utils/schedule'),files=require('../../utils/import');
const api=require('../../utils/api'),ui=require('../../utils/page'),times=require('../../utils/class-times'),education=require('../../utils/education');
function display(courses){return (courses||[]).map(c=>({...c,weeksText:c.date?c.date:times.weeksLabel(c.weeks)}));}
Page({
 data:{courses:[],unscheduled:[],preview:[],paste:'',semesterStart:'',semesterName:'',message:'',education:false,ssoReady:false,token:'',busy:false,showTimes:false,periodTimes:[],timeDraft:[],termOptions:[],termIndex:0},
 onShow(){
  const s=store.read();this.setData({courses:display(s.courses),unscheduled:display(s.unscheduledCourses),semesterStart:s.semesterStart||'',semesterName:s.semesterName||'',periodTimes:s.periodTimes||times.defaults});
  const term=education.terms(s.semesterName);this._terms=term.list;this.setData({termOptions:term.list.map(t=>t.label),termIndex:term.list.findIndex(t=>t.key===term.key)});
  const pending=wx.getStorageSync('education-import-result');if(pending&&Array.isArray(pending.courses)&&pending.courses.length){wx.removeStorageSync('education-import-result');this.importPdf(pending.courses,pending.name,pending.metadata||{},pending.warnings||[],{showSuccess:true});}
 },
 input(e){this.setData({paste:e.detail.value});},
 token(e){this.setData({token:e.detail.value});},
 semester(e){this.setData({semesterStart:e.detail.value});store.update({semesterStart:e.detail.value});},
 async file(){
  if(this.data.busy)return;this.setData({busy:true});
  try{
   const file=await files.choose(['csv','json','ics','pdf']);
   if(!file.pdf){this.preview(file.text,file.name.split('.').pop());return;}
   this.setData({paste:'',preview:[],message:'正在识别PDF课表…'});
   const result=await files.pdf(file,'courses');
   if(!result.recognized||!result.data||!Array.isArray(result.data.courses)||!result.data.courses.length){
    this.setData({paste:'',preview:[],message:(result.warnings||[]).join(' ')||'未能识别课程，请使用文字型周课表或CSV/JSON；扫描件请先OCR。'});return;
   }
   const courses=schedule.parse(JSON.stringify(result.data),'json');
   this.importPdf(courses,file.name,result.data,result.warnings||[]);
  }catch(error){this.setData({message:'文件识别或导入失败：'+error.message,paste:''});ui.toast(error);}
  finally{this.setData({busy:false});}
 },
 importPdf(courses,name,metadata={},warnings=[],options={}){
  const save=()=>{
   const existing=store.read();
   const semesterName=metadata.semester||'';
   const sameTerm=!existing.semesterName||existing.semesterName===semesterName;
   const semesterStart=sameTerm&&existing.semesterStart?existing.semesterStart:metadata.semesterStart||'';
   const unscheduled=metadata.unscheduled||[];
   const periodTimes=metadata.periodTimes||existing.periodTimes||times.defaults;
   store.update({courses,unscheduledCourses:unscheduled,semesterName,semesterStart,periodTimes});
   let message=(name||'PDF课表')+'已识别并直接导入，共'+courses.length+'条上课安排；可在“我的课程”核对。';
   if(unscheduled.length)message+='另保留'+unscheduled.length+'门未排时间课程。';
   if(!semesterStart&&courses.some(c=>c.weeks.length))message+='PDF未包含第1教学周日期；请按教学安排选择第1教学周周一，预测才能正确匹配周次。';
   if(warnings.length)message+=' '+warnings.join(' ');
   this.setData({courses:display(courses),unscheduled:display(unscheduled),preview:[],paste:'',semesterName,semesterStart,periodTimes,message});
   if(options.showSuccess){wx.showModal({title:'课表导入成功',content:'已将'+(name||'课程表')+'识别并放入【'+(semesterName||'当前学期')+'】。请再次核对课程信息，避免上课时间错误。',showCancel:false,confirmText:'查看课表'});}else wx.showToast({title:'PDF课表已导入'});
  };
  const existing=store.read().courses||[];
  if(!existing.length){save();return;}
  wx.showModal({title:'替换现有课表？',content:'PDF已识别'+courses.length+'条上课安排。确认后将替换当前'+existing.length+'门已保存课程。',confirmText:'替换并导入',
   success:r=>{if(r.confirm)save();else this.setData({paste:'',preview:[],message:'PDF已识别，保留了现有课表；如需导入，请再次选择并确认替换。'});}
  });
 },
 preview(text,format){
  try{this.setData({preview:display(schedule.parse(text,format)),message:'解析成功，请核对后确认导入'});}
  catch(error){ui.toast(error);}
 },
 parsePaste(){this.preview(this.data.paste);},
 confirm(){
  if(!this.data.preview.length)return;
  const courses=schedule.parse(JSON.stringify(this.data.preview),'json');
  store.update({courses,unscheduledCourses:[],semesterName:''});
  this.setData({courses:display(courses),unscheduled:[],semesterName:'',preview:[],paste:'',message:'课表已保存，预测会使用上课前与下课后的出行时段'});
  wx.showToast({title:'导入成功'});
 },
 toggleTimes(){this.setData({showTimes:!this.data.showTimes,timeDraft:(store.read().periodTimes||times.defaults).map(t=>({...t}))});},
 periodChange(e){
  const index=Number(e.currentTarget.dataset.index),field=e.currentTarget.dataset.field;
  if(!['start','end'].includes(field)||!this.data.timeDraft[index])return;
  const draft=this.data.timeDraft.map(t=>({...t}));draft[index][field]=e.detail.value;this.setData({timeDraft:draft});
 },
 saveTimes(){
  try{
   const periodTimes=times.validate(this.data.timeDraft),courses=times.remap(store.read().courses||[],periodTimes);
   store.update({periodTimes,courses});this.setData({periodTimes,courses:display(courses),showTimes:false,message:'节次时间已保存，已同步更新导入课程的上下课时间。'});wx.showToast({title:'时间已更新'});
  }catch(error){this.setData({message:error.message});ui.toast(error);}
 },
 education(){wx.navigateTo({url:'/pages/education/index?semesterName='+encodeURIComponent(this.data.semesterName||education.currentTerm())});},
 switchTerm(e){try{const term=this._terms[Number(e.detail.value)];if(!term)return;education.switchTerm(term.key);this.onShow();}catch(error){ui.toast(error);}},
 clear(){wx.showModal({title:'移除课表',content:'只移除本设备已导入的课程与待排课程，不会修改教务系统。',success:r=>{if(r.confirm){store.update({courses:[],unscheduledCourses:[],semesterName:''});this.setData({courses:[],unscheduled:[],preview:[],semesterName:''});}}});},
 copyTemplate(){wx.setClipboardData({data:'课程名称,星期,开始时间,结束时间,地点,人数\n高等数学,1,08:00,09:40,4号教学楼,1\n大学英语,1,10:05,11:45,4号教学楼,1'});},
 settings(){wx.navigateTo({url:'/pages/settings/index'});}
});
