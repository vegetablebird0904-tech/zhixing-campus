const dining=require('../../utils/dining'),ui=require('../../utils/page'),search=require('../../utils/search'),geo=require('../../utils/geo'),store=require('../../utils/store'),memory=require('../../utils/preferences'),campus=require('../../data/campus').west;
Page({
 data:{period:'lunch',periods:[{id:'breakfast',name:'早餐'},{id:'lunch',name:'午餐'},{id:'dinner',name:'晚餐'}],modes:[{id:'walk',name:'步行'},{id:'bike',name:'骑行'}],mode:'walk',recommendation:{restaurants:[],summary:''},date:'',time:'',origin:null,originQuery:'',suggestions:[],memoryText:'',busy:false},
 onLoad(){const d=new Date(),pad=n=>String(n).padStart(2,'0'),settings=memory.settings(),period=settings.meal||dining.currentMeal(d);this.setData({mode:settings.mode==='bike'?'bike':'walk',period,date:d.getFullYear()+'-'+pad(d.getMonth()+1)+'-'+pad(d.getDate()),time:settings.meal?dining.periods[period].time:pad(d.getHours())+':'+pad(d.getMinutes()),memoryText:settings.meal?'已恢复常用餐次：'+memory.meals[settings.meal]:''});this.refresh();},
 onShow(){if(this.data.date)this.refresh();},
 periodChange(e){const period=e.currentTarget.dataset.id;if(!dining.periods[period])return;memory.rememberSetting('meal',period);this.setData({period,time:dining.periods[period].time,memoryText:memory.enabled()?'已记住常用餐次：'+memory.meals[period]:'偏好记忆已关闭'});this.refresh();},
 modeChange(e){const mode=e.currentTarget.dataset.id;if(!['walk','bike'].includes(mode))return;memory.rememberSetting('mode',mode);this.setData({mode});this.refresh();},
 dateChange(e){this.setData({date:e.detail.value});this.refresh();},timeChange(e){this.setData({time:e.detail.value});this.refresh();},
 input(e){const q=e.detail.value;this.setData({originQuery:q,origin:null,suggestions:search.search(q)});this.refresh();},
 choose(e){const p=this.data.suggestions[Number(e.currentTarget.dataset.index)];if(p){this.setData({origin:p,originQuery:p.name,suggestions:[]});this.refresh();}},
 confirmOrigin(){const hits=search.search(this.data.originQuery);if(!hits.length)return ui.toast('请输入校内教学楼、宿舍或地点名称');this.setData({origin:hits[0],originQuery:hits[0].name,suggestions:[]});this.refresh();},
 async locate(){this.setData({busy:true});try{const p=await geo.locate();if(!geo.inCampus(campus,p))throw new Error('当前位置不在校内，请搜索校内出发地');this.setData({origin:Object.assign({},p,{name:'我的位置',node:geo.nearest(campus,p).id}),originQuery:'我的位置',suggestions:[]});this.refresh();}catch(e){ui.toast(e);}finally{this.setData({busy:false});}},
 refresh(){const date=new Date(this.data.date+'T'+this.data.time+':00+08:00');if(!Number.isFinite(date.getTime()))return;const recommendation=dining.recommend(date,this.data.period,undefined,this.data.origin,this.data.mode),favorites=store.read().placeFavorites||[];recommendation.restaurants=recommendation.restaurants.map(r=>Object.assign({},r,{favorite:favorites.some(p=>p.id===r.id)}));this.setData({recommendation});},
 route(e){const id=e.currentTarget.dataset.id;dining.setRouteDraft({from:this.data.origin,mode:this.data.mode,date:this.data.date,depart:this.data.time});wx.navigateTo({url:'/pages/route/index?to='+encodeURIComponent(id)+'&dining=1'});},
 favorite(e){const id=e.currentTarget.dataset.id,p=dining.restaurants().find(p=>p.id===id);if(!p)return;const active=store.toggleFavorite('place',p);this.refresh();ui.toast(active?'餐厅已收藏，可在“我的”查看':'已取消收藏');}
});

