const store=require('../../utils/store'),traffic=require('../../utils/traffic'),search=require('../../utils/search'),live=require('../../utils/location'),ui=require('../../utils/page');
Page({data:{campus:'west',location:null,heading:0,locationText:'点击定位，显示我的位置',temperature:'--',weatherText:'添加天气',snapshot:{},query:'',suggestions:[],searching:false,selected:null,road:null,selectedEdge:'',expanded:false,events:[],incident:null},
 onShow(){this._visible=true;ui.tab(this,0);this.refresh();this.weather();if(store.read().online&&require('../../utils/account').current())require('../../utils/api').refreshIncidents().then(()=>{if(this._visible)this.refresh();}).catch(()=>{});clearInterval(this.timer);this.timer=setInterval(()=>{this.refresh();if(store.read().online&&require('../../utils/account').current())require('../../utils/api').refreshIncidents().then(()=>{if(this._visible)this.refresh();}).catch(()=>{});},60000);if(this.data.location)this.locate();},
 onReady(){if(wx.getSetting)wx.getSetting({success:r=>{if(r.authSetting&&r.authSetting['scope.userLocation'])this.locate();}});},
 onHide(){this._visible=false;clearInterval(this.timer);live.stop(this);},onUnload(){this.onHide();},
 refresh(){this.setData({snapshot:traffic.snapshot('west'),events:store.trafficEvents()});const map=this.selectComponent&&this.selectComponent('#home-map');if(map){map.snapshot=null;map.svgDirty=true;map.draw();}},
 weather(){const w=store.read().weather;if(w&&w.available)this.setData({temperature:w.temperature===null?'--':Math.round(w.temperature),weatherText:w.description||'天气已更新'});},
 async locate(){try{await live.start(this);const map=this.selectComponent('#home-map');if(map)map.focusLocation();}catch(e){ui.toast(e);}},
 input(e){const q=e.detail.value;this.setData({query:q,suggestions:search.search(q),searching:!!q});},focus(){if(this.data.query)this.setData({searching:true});},
 choose(e){const p=this.data.suggestions[Number(e.currentTarget.dataset.index)];this.setData({selected:p,searching:false,query:p.name,road:null});const map=this.selectComponent('#home-map');map.zoom(2);map.centerOn(p);},
 confirm(){const hits=search.search(this.data.query);if(hits.length){this.setData({suggestions:hits});this.choose({currentTarget:{dataset:{index:0}}});}else ui.toast('没有找到，试试“图书馆”“4教”等关键词');},
 clear(){this.setData({query:'',suggestions:[],searching:false,selected:null});},go(e){wx.navigateTo({url:'/pages/'+e.currentTarget.dataset.page+'/index'});},
 incidentTap(e){const incident=e.detail;this.setData({incident,road:null,selected:null,selectedEdge:incident.edgeId});const map=this.selectComponent&&this.selectComponent('#home-map');if(map)map.centerOn(incident);},
 showIncident(e){const incident=(this.data.snapshot.incidents||[])[Number(e.currentTarget.dataset.index)];if(incident)this.incidentTap({detail:incident});},closeIncident(){this.setData({incident:null,selectedEdge:''});},
 roadTap(e){this.setData({incident:null});this.setData({road:Object.assign({},e.detail,{status:['畅行','缓行','拥堵'][e.detail.level||0],index:Math.round((e.detail.value||0)*100)}),selectedEdge:e.detail.id,searching:false});},closeRoad(){this.setData({road:null,selectedEdge:''});},
 routeHere(){if(!this.data.selected)return;wx.navigateTo({url:'/pages/route/index?to='+encodeURIComponent(this.data.selected.id)});},toggle(){this.setData({expanded:!this.data.expanded});}
});
