App({globalData:{name:'智行校园'},onLaunch(){require('./utils/store').init();}});
