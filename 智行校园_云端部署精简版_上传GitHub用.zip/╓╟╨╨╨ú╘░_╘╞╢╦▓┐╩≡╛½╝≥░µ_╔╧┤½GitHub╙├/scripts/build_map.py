import json,xml.etree.ElementTree as E,math,pathlib,collections
base=pathlib.Path(__file__).resolve().parents[1]
def inside(p,poly):
 x,y=p;v=False
 for a,b in zip(poly,poly[1:]+poly[:1]):
  if (a[1]>y)!=(b[1]>y) and x<(b[0]-a[0])*(y-a[1])/(b[1]-a[1])+a[0]:v=not v
 return v
def distance(a,b):return round(math.hypot((a[0]-b[0])*89000,(a[1]-b[1])*111000),1)
all={}
for key,file,wid,label in [('west','west.osm','360350324','西校区'),('east','east.osm','995869233','东校区')]:
 r=E.parse(base/'data'/file).getroot();nn={x.get('id'):(float(x.get('lon')),float(x.get('lat'))) for x in r.findall('node')};ways=r.findall('way');bw=next(w for w in ways if w.get('id')==wid);boundary=[nn[x.get('ref')] for x in bw.findall('nd')]
 edges=[];buildings=[];pois=[];nodes={}
 for w in ways:
  tags={x.get('k'):x.get('v') for x in w.findall('tag')};refs=[x.get('ref') for x in w.findall('nd') if x.get('ref') in nn];pts=[nn[i] for i in refs]
  if not pts:continue
  if tags.get('highway') and tags['highway'] not in ['construction','proposed','steps']:
   for j,(a,b) in enumerate(zip(refs,refs[1:])):
    mid=((nn[a][0]+nn[b][0])/2,(nn[a][1]+nn[b][1])/2)
    if inside(mid,boundary) and a!=b:
     length=distance(nn[a],nn[b])
     if length<1:continue
     nodes[a]=nn[a];nodes[b]=nn[b]
     edges.append({'id':w.get('id')+'-'+str(j),'a':a,'b':b,'length':length,'name':tags.get('name') or {'footway':'步行道','path':'校园小径','service':'校园支路','pedestrian':'步行广场'}.get(tags['highway'],'校园道路'),'kind':tags['highway'],'car':tags['highway'] not in ['footway','path','pedestrian','cycleway'] and tags.get('motor_vehicle')!='no','bike':tags.get('bicycle')!='no','oneway':tags.get('oneway')=='yes','risk':0.65 if tags['highway'] in ['service','residential','unclassified'] else 0.2})
  center=(sum(p[0] for p in pts)/len(pts),sum(p[1] for p in pts)/len(pts))
  if inside(center,boundary):
   if tags.get('building'):buildings.append({'points':pts,'name':tags.get('name','')})
   if tags.get('name') and (tags.get('building') or tags.get('amenity') or tags.get('leisure')) and w.get('id')!=wid:pois.append({'id':w.get('id'),'name':tags['name'],'longitude':center[0],'latitude':center[1]})
 for n in r.findall('node'):
  tags={x.get('k'):x.get('v') for x in n.findall('tag')};p=nn[n.get('id')]
  if inside(p,boundary) and tags.get('name') and (tags.get('amenity') or tags.get('entrance') or tags.get('shop')):pois.append({'id':n.get('id'),'name':tags['name'],'longitude':p[0],'latitude':p[1]})
 # Name only actual mapped locations; include named road midpoints when east has few POIs.
 names=set(p['name'] for p in pois)
 for w in ways:
  t={x.get('k'):x.get('v') for x in w.findall('tag')};pts=[nn[x.get('ref')] for x in w.findall('nd') if x.get('ref') in nn]
  if t.get('highway') and t.get('name') and t['name'] not in names and pts:
   p=pts[len(pts)//2]
   if inside(p,boundary):pois.append({'id':w.get('id'),'name':t['name'],'longitude':p[0],'latitude':p[1]});names.add(t['name'])
 for p in pois:
  p['node']=min(nodes,key=lambda i:distance(nodes[i],(p['longitude'],p['latitude']))) if nodes else ''
 bounds=[min(p[0] for p in boundary),min(p[1] for p in boundary),max(p[0] for p in boundary),max(p[1] for p in boundary)]
 all[key]={'id':key,'name':label,'boundary':boundary,'bounds':bounds,'center':{'longitude':(bounds[0]+bounds[2])/2,'latitude':(bounds[1]+bounds[3])/2},'nodes':nodes,'edges':edges,'buildings':buildings,'pois':pois,'source':{'provider':'OpenStreetMap contributors','license':'ODbL 1.0','retrieved':'2026-10-16','boundaryWay':wid,'coordinates':'WGS84'}}
 print(key,'nodes',len(nodes),'edges',len(edges),'buildings',len(buildings),'pois',len(pois),[p['name'] for p in pois][:18])
(base/'data'/'campus.json').write_text(json.dumps(all,ensure_ascii=False,separators=(',',':')),encoding='utf8')
(base/'data'/'campus.js').write_text('module.exports = '+json.dumps(all,ensure_ascii=False,separators=(',',':'))+';\n',encoding='utf8')
