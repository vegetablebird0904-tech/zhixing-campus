"""Package the complete project without local data or private settings."""
from pathlib import Path
import argparse, json, zipfile, hashlib
base = Path(__file__).resolve().parents[1]
version = json.loads((base / 'package.json').read_text(encoding='utf8'))['version']
parser = argparse.ArgumentParser()
parser.add_argument('--output', type=Path, default=base.parent / ('智行校园-修复连接与教务导课版-v' + version + '.zip'))
args = parser.parse_args()
files = []
for file in sorted(base.rglob('*')):
    if not file.is_file():
        continue
    rel = file.relative_to(base)
    if any(part in ['storage', '.tmp', 'artifacts', '__pycache__', '.vscode'] for part in rel.parts):
        continue
    if file.suffix in ['.tmp', '.zip', '.pyc'] or file.name in ['.env', 'project.private.config.json']:
        continue
    files.append(file)
with zipfile.ZipFile(args.output, 'w', zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
    for file in files:
        archive_name = file.relative_to(base).as_posix()
        if file.relative_to(base).as_posix() == 'utils/lan-config.js':
            archive.writestr(archive_name, "'use strict';\n// Generated locally by the phone-test launcher.\nmodule.exports = {endpoints:[]};\n")
        elif file.relative_to(base).as_posix() == 'data/service-config.js':
            archive.writestr(archive_name, "'use strict';\n// Generated locally by the phone-test launcher; no credentials or saved addresses.\nmodule.exports={app:'zhixing-campus',instanceId:'',endpoints:[]};\n")
        else:
            archive.write(file, archive_name)
with zipfile.ZipFile(args.output) as archive:
    assert archive.testzip() is None
    names = set(archive.namelist())
    for required in ['project.config.json', 'app.json', 'data/uci-demand.js', 'data/service-config.js', 'utils/traffic.js', 'utils/lan-config.js']:
        assert required in names, f'Missing project-root file: {required}'
    project = json.loads(archive.read('project.config.json'))
    assert project.get('miniprogramRoot', './') in ['./', ''], 'Project must open from the extracted root'
    application = json.loads(archive.read('app.json'))
    for page in application['pages']:
        for extension in ['js', 'json', 'wxml', 'wxss']:
            assert page + '.' + extension in names, f'Incomplete page: {page}.{extension}'
    assert not any('/storage/' in name or name.startswith('.tmp/') or name.startswith('.vscode/') for name in names)
    assert not any(name.startswith('zhixing-campus/') for name in names), 'Archive must not add a nested project directory'
    lan_config = archive.read('utils/lan-config.js').decode('utf8')
    assert 'endpoints:[]' in lan_config and '172.' not in lan_config and '192.168.' not in lan_config
    service_config = archive.read('data/service-config.js').decode('utf8')
    assert 'endpoints:[]' in service_config and 'instanceId:\'\'' in service_config and '172.' not in service_config and '192.168.' not in service_config
print(str(args.output.resolve()))
print('Files:', len(files), 'Bytes:', args.output.stat().st_size)
print('SHA256:', hashlib.sha256(args.output.read_bytes()).hexdigest())
