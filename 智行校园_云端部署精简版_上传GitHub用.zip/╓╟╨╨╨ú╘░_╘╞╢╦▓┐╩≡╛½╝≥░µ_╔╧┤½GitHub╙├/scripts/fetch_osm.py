"""Download the two OSM extracts used by this project. Python stdlib only."""
from pathlib import Path
from urllib.request import Request, urlopen
base = Path(__file__).resolve().parents[1]
for name, bbox in [('west','117.985,36.803,118.006,36.817'), ('east','118.025,36.800,118.055,36.825')]:
    url = 'https://www.openstreetmap.org/api/0.6/map?bbox=' + bbox
    with urlopen(Request(url, headers={'User-Agent':'ZhixingCampusEducational/1.0'}), timeout=60) as response:
        data = response.read()
    (base / 'data' / (name + '.osm')).write_bytes(data)
    print(name, len(data), 'bytes; source: OpenStreetMap contributors, ODbL 1.0')
