import urllib.request,zipfile,io,csv,hashlib,json,pathlib,collections
b=pathlib.Path(__file__).resolve().parents[1];raw=urllib.request.urlopen('https://archive.ics.uci.edu/static/public/275/bike+sharing+dataset.zip',timeout=35).read();z=zipfile.ZipFile(io.BytesIO(raw));name=next(n for n in z.namelist() if n.endswith('hour.csv'));rows=list(csv.DictReader(io.TextIOWrapper(z.open(name),encoding='utf-8-sig')));hours=collections.defaultdict(list)
for r in rows:hours[int(r['hr'])].append(int(r['cnt']))
means=[round(sum(hours[h])/len(hours[h]),4) for h in range(24)]
out={'source':'UCI Bike Sharing Dataset','creators':['Hadi Fanaee-T','Joao Gama'],'doi':'10.24432/C5W894','license':'CC BY 4.0','url':'https://archive.ics.uci.edu/dataset/275/bike+sharing+dataset','retrieved':'2026-10-16','sha256':hashlib.sha256(raw).hexdigest(),'records':len(rows),'meanHourlyRentals':means,'normalizedHourlyDemand':[round(x/max(means),5) for x in means],'note':'Washington DC public bike rentals, 2011-2012. Used only as an illustrative diurnal shape; not SDUT traffic observations.'}
(b/'data/uci-demand.json').write_text(json.dumps(out,ensure_ascii=False,indent=2),encoding='utf8');print('UCI records',len(rows),'sha256',out['sha256'])

# WeChat service modules do not use Node's JSON require loader.
(b/"data/uci-demand.js").write_text("// Generated from UCI Bike Sharing Dataset, CC BY 4.0.\nmodule.exports = " + json.dumps(out, ensure_ascii=False, indent=2) + ";\n", encoding="utf8")
