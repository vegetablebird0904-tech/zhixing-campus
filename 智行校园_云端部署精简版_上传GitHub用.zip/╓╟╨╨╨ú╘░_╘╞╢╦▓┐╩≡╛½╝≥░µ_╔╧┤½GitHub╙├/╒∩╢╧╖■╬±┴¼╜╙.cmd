@echo off
chcp 65001 >nul
cd /d "%~dp0"
if exist "%~dp0runtime\node.exe" (
  "%~dp0runtime\node.exe" "%~dp0server\diagnose.js"
) else (
  echo 缺少随附运行环境，请完整解压本次压缩包。
)
pause
